/**
 * UPSC Study Desk - Study Mode Component
 * Isolated, focused study environment for video/PDF content
 * 
 * KEY DESIGN: File system is the source of truth.
 * Files are scanned LIVE from disk, not from stored filenames.
 */

const StudyMode = {
    // Current lecture being studied
    currentLecture: null,

    // Actual file from disk (refreshed on each open)
    currentFile: null,

    // Session tracking to prevent race conditions
    activeSessionId: 0,

    // Current media object URL (for cleanup)
    currentObjectURL: null,

    /**
     * Enter Study Mode for a lecture
     * @param {string} lectureId
     * @param {object} options - { fromRecentlyPlayed: boolean }
     */
    async enter(lectureId, options = {}) {
        // Track entry source for error display
        this.fromRecentlyPlayed = options.fromRecentlyPlayed || false;

        // 1. Start new session
        const thisSessionId = ++this.activeSessionId;
        console.log(`[StudyMode] Starting session ${thisSessionId} for lecture ${lectureId}`);

        // 2. Save position if switching from another lecture
        if (this.currentLecture) {
            await this.savePosition();
        }

        // 3. Immediate cleanup
        this.cleanup();

        const lecture = await AppState.getLecture(lectureId);

        // Race check (if another enter was called during await)
        if (this.activeSessionId !== thisSessionId) {
            console.log(`[StudyMode] Session ${thisSessionId} aborted (stale).`);
            return;
        }

        if (!lecture) {
            console.error('Lecture not found:', lectureId);
            return;
        }

        this.currentLecture = lecture;
        AppState.mode = 'study';

        // Track last opened time
        this.currentLecture.lastOpenedAt = new Date().toISOString();
        await DB.put('lectures', this.currentLecture);
        AppState.invalidateCache();

        // 3. Live Scan
        await this.refreshFileFromDisk();

        // Race check
        if (this.activeSessionId !== thisSessionId) return;

        // 4. Update UI Mode
        const modeBadge = document.querySelector('.mode-badge');
        if (modeBadge) {
            modeBadge.textContent = 'Study Mode';
            modeBadge.className = 'mode-badge study-mode';
        }

        const sidebar = Utils.$('sidebar');
        if (sidebar) sidebar.classList.add('hidden');

        // 5. Render (Pass ID to enforce valid render)
        await this.render(thisSessionId);
    },

    /**
     * Refresh current file from disk (live scan)
     * Sets this.fileError if file/folder is missing
     */
    async refreshFileFromDisk() {
        this.currentFile = null;
        this.fileError = null; // Clear previous error

        if (!FileSystem.hasMasterFolder()) {
            this.fileError = {
                type: 'no_master',
                message: 'No master folder configured. Please select your study materials folder.'
            };
            return;
        }

        try {
            const course = await AppState.getCourse(this.currentLecture.courseId);
            if (!course) {
                this.fileError = {
                    type: 'course_missing',
                    message: `Course data not found in database (ID: ${this.currentLecture.courseId}).`
                };
                return;
            }

            if (!course.folderPath) {
                this.fileError = {
                    type: 'no_path',
                    message: 'Course folder path not defined.'
                };
                return;
            }

            let folder;
            try {
                folder = await FileSystem.getOrCreateFolder(course.folderPath);
            } catch (folderErr) {
                // Folder was moved/deleted/renamed
                this.fileError = {
                    type: 'folder_missing',
                    message: `Folder not found at expected location.`,
                    path: course.folderPath,
                    hint: 'The folder may have been moved, renamed, or deleted.'
                };
                return;
            }

            const files = [];
            for await (const [name, handle] of folder) {
                if (handle.kind === 'file') {
                    const type = FileSystem.classifyFile(name);
                    if (type) files.push({ name, handle, type });
                }
            }

            files.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

            // Match by order index
            const orderIndex = this.currentLecture.orderIndex || 0;
            if (orderIndex < files.length) {
                this.currentFile = files[orderIndex];

                // Sync filename if changed (renamed on disk)
                if (this.currentLecture.fileName !== this.currentFile.name) {
                    this.currentLecture.fileName = this.currentFile.name;
                    this.currentLecture.title = FileSystem.getTitleFromFilename(this.currentFile.name);
                    await DB.put('lectures', this.currentLecture);
                    AppState.invalidateCache();
                }
            } else {
                // File no longer at that index
                this.fileError = {
                    type: 'file_missing',
                    message: `File not found at expected position (index: ${orderIndex}).`,
                    path: course.folderPath,
                    expectedFile: this.currentLecture.fileName,
                    hint: `Expected file: "${this.currentLecture.fileName}". The file may have been moved or deleted.`
                };
            }
        } catch (err) {
            console.error('Error refreshing file from disk:', err);
            this.fileError = {
                type: 'unknown',
                message: `Error accessing file: ${err.message}`
            };
        }
    },

    /**
     * Exit Study Mode
     */
    async exit() {
        // Increment session ID to invalidate any pending loads
        this.activeSessionId++;

        await this.savePosition();
        this.cleanup();

        this.currentLecture = null;
        this.currentFile = null;
        AppState.mode = 'browse';

        const modeBadge = document.querySelector('.mode-badge');
        if (modeBadge) {
            modeBadge.textContent = 'Browse Mode';
            modeBadge.className = 'mode-badge browse-mode';
        }

        const sidebar = Utils.$('sidebar');
        if (sidebar) sidebar.classList.remove('hidden');

        await App.render();
    },

    /**
     * Render the study mode interface
     */
    async render(sessionId) {
        // Race check
        if (sessionId && this.activeSessionId !== sessionId) return;

        const container = Utils.$('content-area');
        if (!container) return;

        Utils.clearElement(container);
        container.className = 'content-area study-mode-active';

        // Header
        const header = Utils.createElement('div', { className: 'study-header' }, [
            Utils.createElement('button', {
                className: 'btn btn-secondary study-back-btn',
                onClick: async () => await this.exit()
            }, '← Back'),
            Utils.createElement('h2', { className: 'study-title' }, this.currentLecture.title),
            Utils.createElement('div', { className: 'study-actions' }, [
                Utils.createElement('button', {
                    className: `btn ${this.currentLecture.completed ? 'btn-success' : 'btn-secondary'}`,
                    onClick: async () => await this.toggleComplete()
                }, this.currentLecture.completed ? '✓ Completed' : 'Mark Complete'),
                // Documents button (only for video lectures)
                this.currentLecture.type === 'video' ? Utils.createElement('button', {
                    className: 'btn btn-secondary',
                    id: 'documents-btn',
                    onClick: () => this.showDocumentPicker()
                }, '📄 Documents') : null
            ].filter(Boolean))
        ]);
        container.appendChild(header);

        // Check for file access errors
        if (this.fileError) {
            let errorBox;

            if (this.fromRecentlyPlayed) {
                // Detailed error for Recently Played items (stale reference - user's fault)
                errorBox = Utils.createElement('div', { className: 'study-error-box' }, [
                    Utils.createElement('div', { className: 'study-error-icon' }, '⚠️'),
                    Utils.createElement('h3', { className: 'study-error-title' }, 'File Not Found'),
                    Utils.createElement('p', { className: 'study-error-message' }, this.fileError.message),
                    this.fileError.path ? Utils.createElement('div', { className: 'study-error-path' }, [
                        Utils.createElement('strong', {}, 'Expected Location: '),
                        Utils.createElement('code', {}, this.fileError.path)
                    ]) : null,
                    this.fileError.expectedFile ? Utils.createElement('div', { className: 'study-error-file' }, [
                        Utils.createElement('strong', {}, 'Expected File: '),
                        Utils.createElement('code', {}, this.fileError.expectedFile)
                    ]) : null,
                    this.fileError.hint ? Utils.createElement('p', { className: 'study-error-hint' }, this.fileError.hint) : null,
                    Utils.createElement('p', { className: 'study-error-action' },
                        'This is likely because you moved or renamed the folder. The stored Recently Played data is now stale.'
                    ),
                    Utils.createElement('button', {
                        className: 'btn btn-secondary',
                        onClick: async () => await this.exit()
                    }, '← Go Back')
                ].filter(Boolean));
            } else {
                // Simple error for normal browse (just ask to refresh)
                errorBox = Utils.createElement('div', { className: 'study-error-box' }, [
                    Utils.createElement('div', { className: 'study-error-icon' }, '🔄'),
                    Utils.createElement('h3', { className: 'study-error-title' }, 'Content Not Available'),
                    Utils.createElement('p', { className: 'study-error-message' },
                        'The file could not be found. The folder structure may have changed.'
                    ),
                    Utils.createElement('p', { className: 'study-error-hint' },
                        'Please refresh the page to load the updated file structure.'
                    ),
                    Utils.createElement('button', {
                        className: 'btn btn-primary',
                        onClick: () => window.location.reload()
                    }, '🔄 Refresh Page'),
                    Utils.createElement('button', {
                        className: 'btn btn-secondary',
                        onClick: async () => await this.exit()
                    }, '← Go Back')
                ]);
            }

            container.appendChild(errorBox);
            return;
        }

        // Main Content
        const mainArea = Utils.createElement('div', { className: 'study-main' });

        if (this.currentLecture.type === 'video') {
            await this.renderVideoPlayer(mainArea, sessionId);
        } else if (this.currentLecture.type === 'pdf') {
            await this.renderPdfViewer(mainArea);
        }

        container.appendChild(mainArea);
    },

    /**
     * Render video player with Plyr integration
     */
    async renderVideoPlayer(container, sessionId) {
        const videoWrapper = Utils.createElement('div', { className: 'video-wrapper' });

        // Fallback or Loading
        if (!this.currentFile) {
            videoWrapper.innerHTML = '<div class="study-fallback">Video file not found in folder.</div>';
            container.appendChild(videoWrapper);
            return;
        }

        try {
            // Create Blob URL
            const file = await this.currentFile.handle.getFile();

            // Race check: If session changed while reading file
            if (sessionId && this.activeSessionId !== sessionId) return;

            this.currentObjectURL = URL.createObjectURL(file);

            const video = Utils.createElement('video', {
                className: 'study-video',
                controls: 'true',
                playsinline: 'true',
                preload: 'metadata'
            });
            video.src = this.currentObjectURL;

            // Append FIRST (Plyr needs it in DOM)
            videoWrapper.appendChild(video);
            container.appendChild(videoWrapper);

            // Initialize Plyr
            if (window.Plyr) {
                this.player = new Plyr(video, {
                    controls: [
                        'play-large', 'play', 'progress', 'current-time', 'duration',
                        'mute', 'volume', 'captions', 'settings', 'pip', 'fullscreen'
                    ],
                    speed: { selected: 1, options: [0.5, 0.75, 1, 1.25, 1.5, 2] },
                    keyboard: { focused: true, global: true },
                    tooltips: { controls: true, seek: true },
                    // Fix blank screen issues
                    ratio: '16:9',
                    resetOnEnd: true
                });

                // Restore logic helper
                const restorePosition = () => {
                    if (this.currentLecture && this.currentLecture.lastPosition > 0) {
                        console.log(`[StudyMode] Restoring position: ${this.currentLecture.lastPosition}s`);
                        // Try immediately
                        this.player.currentTime = this.currentLecture.lastPosition;
                        // And safe check
                        setTimeout(() => {
                            if (this.player && Math.abs(this.player.currentTime - this.currentLecture.lastPosition) > 1) {
                                this.player.currentTime = this.currentLecture.lastPosition;
                            }
                        }, 100);
                    }
                };

                // Attach Events via Plyr API
                this.player.on('ready', restorePosition);
                this.player.on('loadedmetadata', restorePosition);

                this.player.on('timeupdate', () => {
                    // Throttle save
                    if (this.currentLecture && Math.random() < 0.1) {
                        this.currentLecture.lastPosition = Math.floor(this.player.currentTime);
                        DB.put('lectures', this.currentLecture);
                    }
                });

                this.player.on('pause', () => {
                    if (this.currentLecture) {
                        const time = Math.floor(this.player.currentTime);
                        console.log(`[StudyMode] Paused. Saving position: ${time}s`);
                        this.currentLecture.lastPosition = time;
                        DB.put('lectures', this.currentLecture);
                    }
                });

                this.player.on('ended', () => {
                    this.savePosition();
                    if (!this.currentLecture.completed) {
                        this.showCompletionPrompt();
                        this.currentLecture.completed = true;
                        DB.put('lectures', this.currentLecture);
                    }
                });
            } else {
                // Fallback to native events
                video.addEventListener('loadedmetadata', () => {
                    if (this.currentLecture.lastPosition > 0) video.currentTime = this.currentLecture.lastPosition;
                });
                video.addEventListener('pause', () => {
                    this.currentLecture.lastPosition = Math.floor(video.currentTime);
                    DB.put('lectures', this.currentLecture);
                });
            }

        } catch (err) {
            console.error('Video Load Error:', err);
            videoWrapper.innerHTML = `<div class="study-fallback">Error loading video: ${err.message}</div>`;
            container.appendChild(videoWrapper);
        }
    },

    /**
     * PDF Viewer using full PDF.js Viewer (All Features)
     * Includes: Zoom, Fit to Page, Search, Highlights, Print
     */
    async renderPdfViewer(container) {
        container.innerHTML = '';
        container.classList.add('pdf-viewer-mode');

        if (!this.currentFile) {
            container.innerHTML = '<div class="pdf-error">PDF file not found.</div>';
            return;
        }

        try {
            // Create Blob URL (works on HTTP servers)
            const file = await this.currentFile.handle.getFile();
            const blobUrl = URL.createObjectURL(file);

            // Save for cleanup
            this.currentObjectURL = blobUrl;

            // Initial page from saved position
            const initialPage = this.currentLecture?.lastPosition || 1;

            // Full PDF.js Viewer URL
            const viewerUrl = `js/vendor/pdfjs/web/viewer.html?file=${encodeURIComponent(blobUrl)}#page=${initialPage}`;

            // Create iframe with full viewer
            const iframe = document.createElement('iframe');
            iframe.className = 'pdf-viewer-frame';
            iframe.src = viewerUrl;
            iframe.setAttribute('allowfullscreen', 'true');
            iframe.style.cssText = 'width:100%;height:100%;border:none;';

            container.appendChild(iframe);

            // Try to hook into viewer for page persistence
            iframe.onload = () => {
                try {
                    const win = iframe.contentWindow;
                    if (win && win.PDFViewerApplication) {
                        // Wait for initialization
                        const checkInit = setInterval(() => {
                            if (win.PDFViewerApplication.initialized) {
                                clearInterval(checkInit);

                                // Page change listener
                                win.PDFViewerApplication.eventBus.on('pagechanging', (e) => {
                                    if (this.currentLecture) {
                                        this.currentLecture.lastPosition = e.pageNumber;
                                        DB.put('lectures', this.currentLecture);
                                    }
                                });
                            }
                        }, 200);

                        setTimeout(() => clearInterval(checkInit), 10000);
                    }
                } catch (e) {
                    console.warn('Could not hook viewer events:', e);
                }
            };

        } catch (err) {
            console.error('PDF Load Error:', err);
            container.innerHTML = `<div class="pdf-error">Failed to load PDF: ${err.message}</div>`;
        }
    },

    /**
     * Save current position
     */
    async savePosition() {
        if (!this.currentLecture) return;

        if (this.currentLecture.type === 'video' && this.player) {
            this.currentLecture.lastPosition = Math.floor(this.player.currentTime);
            console.log(`[StudyMode] savePosition called. Saving: ${this.currentLecture.lastPosition}s`);
        }
        // If no player active, rely on the last periodic save

        await DB.put('lectures', this.currentLecture);
    },

    toggleComplete() {
        // ... simple toggle logic ...
        // For brevity reusing existing pattern but ensure it calls DB put
        this.currentLecture.completed = !this.currentLecture.completed;
        DB.put('lectures', this.currentLecture);
        this.render(this.activeSessionId);
    },

    showCompletionPrompt() {
        const container = Utils.$('content-area');
        const prompt = Utils.createElement('div', { className: 'completion-prompt' }, [
            Utils.createElement('div', { className: 'completion-icon' }, '🎉'),
            Utils.createElement('div', { className: 'completion-title' }, 'Lecture Completed!'),
            Utils.createElement('div', { className: 'completion-actions' }, [
                Utils.createElement('button', {
                    className: 'btn btn-primary',
                    onClick: async () => await this.goToNextLecture()
                }, 'Next Lecture →'),
                Utils.createElement('button', {
                    className: 'btn btn-secondary',
                    onClick: async () => await this.exit()
                }, 'Back to List'),
                Utils.createElement('button', {
                    className: 'btn btn-secondary',
                    onClick: () => prompt.remove()
                }, 'Stay Here')
            ])
        ]);
        container.appendChild(prompt);
    },

    /**
     * Robust Cleanup
     */
    cleanup() {
        // 1. Destroy Plyr
        if (this.player) {
            try {
                this.player.destroy(); // This also pauses video
            } catch (e) {
                console.warn('Plyr destroy failed', e);
            }
            this.player = null;
        }

        // 2. Kill Object URL (Critical for memory)
        if (this.currentObjectURL) {
            URL.revokeObjectURL(this.currentObjectURL);
            this.currentObjectURL = null;
        }

        // 3. Aggressive Media Cleanup (for native elements if Plyr failed)
        document.querySelectorAll('video, audio').forEach(el => {
            el.pause();
            el.src = '';
            el.load();
        });

        // 4. Reset State
        this.currentLecture = null;
        this.currentFile = null;
    },

    async goToNextLecture() {
        const lectures = await AppState.getLectures(this.currentLecture.courseId);
        const idx = lectures.findIndex(l => l.id === this.currentLecture.id);
        for (let i = idx + 1; i < lectures.length; i++) {
            if (!lectures[i].completed) {
                await this.enter(lectures[i].id);
                return;
            }
        }
        await this.exit();
    },

    /**
     * Show document picker modal with PDFs from current course folder
     */
    async showDocumentPicker() {
        if (!this.currentLecture) return;

        // Get course folder
        const course = await AppState.getCourse(this.currentLecture.courseId);
        if (!course || !course.folderPath) {
            alert('Course folder not found.');
            return;
        }

        try {
            const folder = await FileSystem.getOrCreateFolder(course.folderPath);
            const pdfs = [];

            for await (const [name, handle] of folder) {
                if (handle.kind === 'file' && name.toLowerCase().endsWith('.pdf')) {
                    pdfs.push({ name, handle });
                }
            }

            if (pdfs.length === 0) {
                alert('No PDF documents found in this course folder.');
                return;
            }

            // Show picker modal
            this.showPdfPickerModal(pdfs);
        } catch (err) {
            console.error('Error loading documents:', err);
            alert('Could not load documents. Please check folder permissions.');
        }
    },

    /**
     * Show PDF picker modal
     */
    showPdfPickerModal(pdfs) {
        // Remove existing modal if any
        const existing = document.getElementById('pdf-picker-modal');
        if (existing) existing.remove();

        const modal = Utils.createElement('div', {
            className: 'pdf-picker-modal',
            id: 'pdf-picker-modal'
        }, [
            Utils.createElement('div', { className: 'pdf-picker-content' }, [
                Utils.createElement('div', { className: 'pdf-picker-header' }, [
                    Utils.createElement('h3', {}, '📄 Select a Document'),
                    Utils.createElement('button', {
                        className: 'pdf-picker-close',
                        onClick: () => modal.remove()
                    }, '×')
                ]),
                Utils.createElement('div', { className: 'pdf-picker-list' },
                    pdfs.map(pdf => Utils.createElement('div', {
                        className: 'pdf-picker-item',
                        onClick: async () => {
                            modal.remove();
                            await this.loadSplitPDF(pdf);
                        }
                    }, [
                        Utils.createElement('span', { className: 'pdf-picker-icon' }, '📄'),
                        Utils.createElement('span', { className: 'pdf-picker-name' }, pdf.name)
                    ]))
                )
            ])
        ]);

        document.body.appendChild(modal);
    },

    /**
     * Load PDF in split view beside video
     */
    async loadSplitPDF(pdf) {
        const container = Utils.$('content-area');
        const mainArea = container?.querySelector('.study-main');
        if (!mainArea) return;

        // Check if already in split view
        if (mainArea.classList.contains('split-view')) {
            // Just update the PDF
            this.updateSplitPDF(pdf);
            return;
        }

        // Get existing video wrapper
        const videoWrapper = mainArea.querySelector('.video-wrapper');
        if (!videoWrapper) return;

        // ==============================
        // 1. HIDE SIDEBAR - Go Full Screen
        // ==============================
        const sidebar = Utils.$('sidebar');
        if (sidebar) sidebar.classList.add('hidden');

        // Hide the top nav bar for maximum space
        const topHeader = document.querySelector('.main-header');
        if (topHeader) topHeader.style.display = 'none';

        // Hide study header to maximize space
        const studyHeader = container?.querySelector('.study-header');
        if (studyHeader) studyHeader.classList.add('split-mode-hidden');

        // ==============================
        // 2. CREATE SPLIT VIEW WITH CONTROL BAR
        // ==============================
        mainArea.classList.add('split-view');

        // Create control bar at top
        const controlBar = Utils.createElement('div', { className: 'split-control-bar' }, [
            Utils.createElement('button', {
                className: 'btn btn-secondary split-back-btn',
                onClick: () => this.closeSplitPDF()
            }, '← Back'),
            Utils.createElement('span', { className: 'split-pdf-name' }, pdf.name),
            Utils.createElement('button', {
                className: 'btn btn-secondary split-close-pdf-btn',
                onClick: () => this.closeSplitPDF()
            }, '✕ Close PDF')
        ]);

        // Create split container
        const splitContainer = Utils.createElement('div', { className: 'split-panels' });

        // Wrap video in left panel
        const leftPanel = Utils.createElement('div', { className: 'split-left' });
        leftPanel.appendChild(videoWrapper);
        splitContainer.appendChild(leftPanel);

        // Create right panel with PDF viewer
        const rightPanel = Utils.createElement('div', { className: 'split-right' }, [
            Utils.createElement('div', { className: 'split-pdf-viewer', id: 'split-pdf-container' })
        ]);
        splitContainer.appendChild(rightPanel);

        // Add to main area
        mainArea.appendChild(controlBar);
        mainArea.appendChild(splitContainer);

        // Load PDF into container
        await this.renderSplitPdfViewer(pdf);
    },

    /**
     * Render PDF in split view container
     */
    async renderSplitPdfViewer(pdf) {
        const container = document.getElementById('split-pdf-container');
        if (!container) return;

        try {
            const file = await pdf.handle.getFile();
            const blobUrl = URL.createObjectURL(file);

            // Use PDF.js viewer in iframe
            const viewerUrl = `js/vendor/pdfjs/web/viewer.html?file=${encodeURIComponent(blobUrl)}`;
            const iframe = document.createElement('iframe');
            iframe.className = 'split-pdf-iframe';
            iframe.src = viewerUrl;
            iframe.style.cssText = 'width:100%;height:100%;border:none;';

            container.innerHTML = '';
            container.appendChild(iframe);
        } catch (err) {
            console.error('Error loading split PDF:', err);
            container.innerHTML = '<div class="pdf-error">Failed to load PDF</div>';
        }
    },

    /**
     * Update PDF in existing split view
     */
    async updateSplitPDF(pdf) {
        const header = document.querySelector('.split-pdf-title');
        if (header) header.textContent = pdf.name;
        await this.renderSplitPdfViewer(pdf);
    },

    /**
     * Close split view and return to full video
     */
    closeSplitPDF() {
        const container = Utils.$('content-area');
        const mainArea = container?.querySelector('.study-main');
        if (!mainArea) return;

        mainArea.classList.remove('split-view');

        // Get elements
        const controlBar = mainArea.querySelector('.split-control-bar');
        const splitPanels = mainArea.querySelector('.split-panels');
        const leftPanel = splitPanels?.querySelector('.split-left');
        const videoWrapper = leftPanel?.querySelector('.video-wrapper');

        // Move video wrapper back to main area
        if (videoWrapper) {
            mainArea.insertBefore(videoWrapper, controlBar || splitPanels);
        }

        // Remove split elements
        if (controlBar) controlBar.remove();
        if (splitPanels) splitPanels.remove();

        // Restore hidden elements
        const studyHeader = container?.querySelector('.study-header');
        if (studyHeader) studyHeader.classList.remove('split-mode-hidden');

        const topHeader = document.querySelector('.main-header');
        if (topHeader) topHeader.style.display = '';

        // Restore sidebar (but keep it hidden in study mode - don't remove the hidden class)
        // Note: sidebar stays hidden in study mode, will show on exit()
    }
};

window.StudyMode = StudyMode;
